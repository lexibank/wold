
WOLD data download
==================

Data of WOLD is published under the following license:
http://creativecommons.org/licenses/by/3.0/de/

It should be cited as

Haspelmath, Martin & Tadmor, Uri (eds.) 2009.
World Loanword Database.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://wold.clld.org, Accessed on 2016-06-24.)

